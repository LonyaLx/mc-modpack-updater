# -*- coding: utf-8 -*-
"""
Minecraft 整合包更新器 - 简化版核心引擎
功能：对比两个整合包目录，增量更新，自动保留用户配置
"""

import os
import json
import hashlib
import shutil
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Callable


class SimpleUpdater:
    """简化版整合包更新器"""

    # 硬保留：用户数据，永远保留，不参与更新/删除
    HARD_PRESERVE_PATTERNS = [
        "saves/",            # 存档（绝对不能动）
        "servers.dat",       # 服务器列表
        "resourcepacks/",    # 资源包
        "shaderpacks/",      # 光影包
        "schematics/",       # 原理图
        "replay_recordings/", # 回放录像
        "screenshots/",      # 截图
        "mods/*.disabled",   # 被禁用的模组
    ]

    # 可选保留：配置文件，用户可选择是否保留
    # 默认不保留（跟随整合包更新）
    CONFIG_PRESERVE_PATTERNS = [
        "config/",           # 模组配置
        "options.txt",       # 游戏选项（键位等）
        "optionsshaders.txt", # 光影设置
    ]

    # 默认忽略的文件/目录（不参与更新）
    DEFAULT_IGNORE_PATTERNS = [
        ".updater/",         # 更新器自身数据
        ".mixin.out/",
        "logs/",             # 日志
        "crash-reports/",    # 崩溃报告
        "versions/",         # 游戏版本目录
        "libraries/",        # 游戏库
        "assets/",           # 游戏资源
        "natives/",          # 原生库
        "runtime/",          # 运行时
        "*.log",
        "*.log.gz",
        "*.tmp",
        ".DS_Store",
        "Thumbs.db",
        "desktop.ini",
    ]

    def __init__(self, old_dir: str, new_dir: str,
                 progress_callback: Optional[Callable] = None,
                 log_callback: Optional[Callable] = None,
                 preserve_config: bool = False,
                 extra_preserve_patterns: Optional[List[str]] = None,
                 ignore_patterns: Optional[List[str]] = None,
                 delete_removed: bool = True):
        """
        初始化更新器
        :param old_dir: 本地旧整合包目录
        :param new_dir: 新整合包目录（要更新到的版本）
        :param progress_callback: 进度回调 (current, total, message)
        :param log_callback: 日志回调 (message, level)
        :param preserve_config: 是否保留配置文件（config/、options.txt 等）
        :param extra_preserve_patterns: 额外的保留文件模式
        :param ignore_patterns: 额外的忽略模式
        :param delete_removed: 是否删除新版本中没有的旧文件
        """
        self.old_dir = Path(old_dir).resolve()
        self.new_dir = Path(new_dir).resolve()
        self.progress_callback = progress_callback or (lambda *a: None)
        self.log_callback = log_callback or (lambda *a: None)
        self.preserve_config = preserve_config
        self.ignore_patterns = list(set(self.DEFAULT_IGNORE_PATTERNS + (ignore_patterns or [])))
        self.delete_removed = delete_removed

        # 组装完整保留列表：硬保留 + 可选配置保留 + 额外保留
        all_preserve = list(self.HARD_PRESERVE_PATTERNS)
        if preserve_config:
            all_preserve += self.CONFIG_PRESERVE_PATTERNS
        if extra_preserve_patterns:
            all_preserve += extra_preserve_patterns
        self.preserve_patterns = list(set(all_preserve))

        self.updater_dir = self.old_dir / ".updater"
        self.backup_dir = self.updater_dir / "backup"
        self.manifest_path = self.updater_dir / "manifest.json"

        self._ensure_dirs()

    def _ensure_dirs(self):
        """确保必要目录存在"""
        self.updater_dir.mkdir(parents=True, exist_ok=True)
        self.backup_dir.mkdir(parents=True, exist_ok=True)

    def _log(self, message: str, level: str = "info"):
        self.log_callback(message, level)

    def _progress(self, current: int, total: int, message: str = ""):
        self.progress_callback(current, total, message)

    @staticmethod
    def file_sha256(filepath: Path) -> str:
        """计算文件 SHA256"""
        h = hashlib.sha256()
        with open(filepath, "rb") as f:
            while True:
                chunk = f.read(8192)
                if not chunk:
                    break
                h.update(chunk)
        return h.hexdigest()

    def _should_ignore(self, rel_path: str) -> bool:
        """检查路径是否应该被忽略"""
        import fnmatch
        rel_path = rel_path.replace("\\", "/")
        for pattern in self.ignore_patterns:
            if pattern.endswith("/"):
                if rel_path.startswith(pattern) or rel_path + "/" == pattern:
                    return True
            elif "*" in pattern:
                if fnmatch.fnmatch(rel_path, pattern) or fnmatch.fnmatch(Path(rel_path).name, pattern):
                    return True
            else:
                if rel_path == pattern:
                    return True
        return False

    def _match_preserve(self, rel_path: str) -> bool:
        """检查路径是否匹配保留模式"""
        import fnmatch
        rel_path = rel_path.replace("\\", "/")
        for pattern in self.preserve_patterns:
            if pattern.endswith("/"):
                if rel_path.startswith(pattern) or rel_path + "/" == pattern:
                    return True
            elif "*" in pattern:
                if fnmatch.fnmatch(rel_path, pattern):
                    return True
            else:
                if rel_path == pattern:
                    return True
        return False

    def scan_directory(self, directory: Path) -> Dict[str, dict]:
        """扫描目录，返回文件清单 {相对路径: {sha256, size}}"""
        result = {}
        if not directory.exists():
            return result

        for root, dirs, files in os.walk(directory):
            root_path = Path(root)
            rel_root = root_path.relative_to(directory)
            rel_root_str = str(rel_root).replace("\\", "/")
            if rel_root_str == ".":
                rel_root_str = ""

            # 过滤忽略的目录
            dirs[:] = [d for d in dirs if not self._should_ignore(
                (rel_root_str + "/" + d + "/").lstrip("/")
            )]

            for file in files:
                rel_path = (rel_root_str + "/" + file).lstrip("/")
                if self._should_ignore(rel_path):
                    continue
                file_path = root_path / file
                try:
                    file_hash = self.file_sha256(file_path)
                    file_size = file_path.stat().st_size
                    result[rel_path] = {
                        "sha256": file_hash,
                        "size": file_size
                    }
                except IOError as e:
                    self._log(f"读取文件失败 {rel_path}: {e}", "warning")

        return result

    def load_manifest(self) -> Optional[dict]:
        """加载本地基准清单（记录上次更新时的文件状态）"""
        if self.manifest_path.exists():
            try:
                with open(self.manifest_path, "r", encoding="utf-8") as f:
                    return json.load(f)
            except (json.JSONDecodeError, IOError):
                return None
        return None

    def save_manifest(self, files: dict, version_label: str = ""):
        """保存基准清单"""
        manifest = {
            "version_label": version_label,
            "update_time": time.strftime("%Y-%m-%d %H:%M:%S"),
            "files": files
        }
        with open(self.manifest_path, "w", encoding="utf-8") as f:
            json.dump(manifest, f, ensure_ascii=False, indent=2)

    def get_user_modified_files(self) -> List[str]:
        """获取用户修改过的文件列表（对比当前文件和基准清单）"""
        manifest = self.load_manifest()
        if not manifest:
            # 没有基准清单，认为所有保留模式的文件都是用户修改的
            return []

        baseline = manifest.get("files", {})
        modified = []

        for rel_path in baseline.keys():
            if not self._match_preserve(rel_path):
                continue
            local_file = self.old_dir / rel_path
            if not local_file.exists():
                continue
            try:
                actual_hash = self.file_sha256(local_file)
                if actual_hash != baseline[rel_path].get("sha256"):
                    modified.append(rel_path)
            except IOError:
                modified.append(rel_path)

        # 还有基准清单中没有但存在的保留文件（用户自己加的）
        for rel_path in self.scan_directory(self.old_dir).keys():
            if self._match_preserve(rel_path) and rel_path not in baseline:
                modified.append(rel_path)

        return modified

    def compare(self) -> Dict:
        """
        对比新旧整合包，计算差异
        :return: {added, modified, removed, preserve_count, total_size, old_count, new_count}
        """
        self._log("扫描旧整合包文件...", "info")
        old_files = self.scan_directory(self.old_dir)
        self._log(f"旧整合包: {len(old_files)} 个文件", "info")

        self._log("扫描新整合包文件...", "info")
        new_files = self.scan_directory(self.new_dir)
        self._log(f"新整合包: {len(new_files)} 个文件", "info")

        added = []
        modified = []
        removed = []
        total_size = 0

        for path, info in new_files.items():
            if path not in old_files:
                added.append(path)
                total_size += info.get("size", 0)
            elif old_files[path].get("sha256") != info.get("sha256"):
                modified.append(path)
                total_size += info.get("size", 0)

        # 删除列表：排除保留文件
        for path in old_files:
            if path not in new_files and not self._match_preserve(path):
                removed.append(path)

        # 统计被保留的文件数（旧包里匹配保留模式且在修改列表中的）
        preserve_modified = [
            p for p in modified
            if self._match_preserve(p)
        ]

        return {
            "added": added,
            "modified": modified,
            "removed": removed,
            "preserve_modified": preserve_modified,
            "preserve_config": self.preserve_config,
            "total_size": total_size,
            "total_count": len(added) + len(modified),
            "old_count": len(old_files),
            "new_count": len(new_files)
        }

    def _backup_before_update(self, changes: Dict) -> str:
        """
        更新前备份（用于回退）
        备份内容：
        - 被修改的文件（旧版本）
        - 被删除的文件
        - 用户修改过的保留配置文件
        - 新增文件列表（回退时删除）
        :return: 备份目录名（时间戳）
        """
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        backup_path = self.backup_dir / timestamp
        backup_path.mkdir(parents=True, exist_ok=True)

        self._log(f"创建备份: {timestamp}", "info")

        added_files = changes.get("added", [])
        modified_files = changes.get("modified", [])
        removed_files = changes.get("removed", [])
        preserve_modified = set(changes.get("preserve_modified", []))

        backup_manifest = {
            "backup_time": time.strftime("%Y-%m-%d %H:%M:%S"),
            "added_files": added_files,        # 本次新增的（回退时删除）
            "modified_files": modified_files,  # 本次修改的（回退时从备份恢复）
            "removed_files": removed_files,    # 本次删除的（回退时从备份恢复）
            "preserve_patterns": self.preserve_patterns
        }

        modified_count = 0
        removed_count = 0
        user_count = 0

        # 1. 备份被修改的文件（旧版本，从旧目录复制）
        for rel_path in modified_files:
            # 保留文件如果被用户修改过，单独备份到 user_files
            if rel_path in preserve_modified:
                src = self.old_dir / rel_path
                if src.exists() and src.is_file():
                    dst = backup_path / "user_files" / rel_path
                    dst.parent.mkdir(parents=True, exist_ok=True)
                    try:
                        shutil.copy2(src, dst)
                        user_count += 1
                    except IOError as e:
                        self._log(f"备份用户配置失败 {rel_path}: {e}", "warning")
                continue

            # 普通修改的文件，备份旧版本
            src = self.old_dir / rel_path
            if src.exists() and src.is_file():
                dst = backup_path / "modified_files" / rel_path
                dst.parent.mkdir(parents=True, exist_ok=True)
                try:
                    shutil.copy2(src, dst)
                    modified_count += 1
                except IOError as e:
                    self._log(f"备份修改文件失败 {rel_path}: {e}", "warning")

        # 2. 备份被删除的文件（保留文件除外）
        for rel_path in removed_files:
            if self._match_preserve(rel_path):
                # 保留的配置文件也备份一下
                src = self.old_dir / rel_path
                if src.exists() and src.is_file():
                    dst = backup_path / "user_files" / rel_path
                    dst.parent.mkdir(parents=True, exist_ok=True)
                    try:
                        shutil.copy2(src, dst)
                        user_count += 1
                    except IOError as e:
                        self._log(f"备份用户配置失败 {rel_path}: {e}", "warning")
                continue

            src = self.old_dir / rel_path
            if src.exists() and src.is_file():
                dst = backup_path / "removed_files" / rel_path
                dst.parent.mkdir(parents=True, exist_ok=True)
                try:
                    shutil.copy2(src, dst)
                    removed_count += 1
                except IOError as e:
                    self._log(f"备份删除文件失败 {rel_path}: {e}", "warning")

        # 3. 还要备份用户修改过、但本次更新没涉及到的保留文件
        # （保证回退后用户配置完整）
        all_user_modified = self.get_user_modified_files()
        for rel_path in all_user_modified:
            if rel_path in preserve_modified:
                continue  # 已经备份过了
            src = self.old_dir / rel_path
            if src.exists() and src.is_file():
                dst = backup_path / "user_files" / rel_path
                if dst.exists():
                    continue
                dst.parent.mkdir(parents=True, exist_ok=True)
                try:
                    shutil.copy2(src, dst)
                    user_count += 1
                except IOError as e:
                    self._log(f"备份用户配置失败 {rel_path}: {e}", "warning")

        backup_manifest["modified_count"] = modified_count
        backup_manifest["removed_count"] = removed_count
        backup_manifest["user_count"] = user_count

        with open(backup_path / "backup_manifest.json", "w", encoding="utf-8") as f:
            json.dump(backup_manifest, f, ensure_ascii=False, indent=2)

        self._log(
            f"备份完成: 修改文件 {modified_count} 个, 删除文件 {removed_count} 个, 用户配置 {user_count} 个",
            "info"
        )
        return timestamp

    def get_backup_list(self) -> List[Dict]:
        """获取可用的备份列表（从新到旧）"""
        if not self.backup_dir.exists():
            return []

        backups = []
        for item in self.backup_dir.iterdir():
            manifest_file = item / "backup_manifest.json"
            if item.is_dir() and manifest_file.exists():
                try:
                    with open(manifest_file, "r", encoding="utf-8") as f:
                        manifest = json.load(f)
                    backups.append({
                        "name": item.name,
                        "time": manifest.get("backup_time", item.name),
                        "user_files": manifest.get("user_count", manifest.get("user_modified_count", 0)),
                        "modified_files": manifest.get("modified_count", 0),
                        "removed_files": manifest.get("removed_count", 0)
                    })
                except (json.JSONDecodeError, IOError):
                    backups.append({
                        "name": item.name,
                        "time": item.name,
                        "user_files": 0,
                        "removed_files": 0
                    })

        backups.sort(key=lambda x: x["name"], reverse=True)
        return backups

    def do_update(self, changes: Optional[Dict] = None) -> Tuple[bool, str]:
        """
        执行更新
        :param changes: 预计算的差异，None 则自动计算
        :return: (成功与否, 消息)
        """
        if not self.old_dir.exists():
            return False, f"旧整合包目录不存在: {self.old_dir}"
        if not self.new_dir.exists():
            return False, f"新整合包目录不存在: {self.new_dir}"

        if changes is None:
            changes = self.compare()

        # 备份
        backup_name = self._backup_before_update(changes)

        added = changes.get("added", [])
        modified = changes.get("modified", [])
        removed = changes.get("removed", []) if self.delete_removed else []
        preserve_modified = set(changes.get("preserve_modified", []))

        total_ops = len(added) + len(modified) + len(removed)
        processed = 0

        if total_ops == 0:
            self._log("没有需要更新的文件", "info")
            return True, "已经是最新状态，无需更新"

        self._log(f"开始更新: 新增 {len(added)}，修改 {len(modified)}，删除 {len(removed)}", "info")

        # 1. 新增和修改文件
        all_to_copy = added + modified
        for rel_path in all_to_copy:
            processed += 1
            src = self.new_dir / rel_path
            dst = self.old_dir / rel_path

            # 用户修改过的保留文件，跳过
            if rel_path in preserve_modified:
                self._log(f"保留用户配置: {rel_path}", "info")
                self._progress(processed, total_ops, f"保留: {rel_path}")
                continue

            try:
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src, dst)
            except IOError as e:
                self._log(f"复制失败 {rel_path}: {e}", "error")
                return False, f"更新失败: {rel_path} - {e}"

            self._progress(processed, total_ops, f"更新: {rel_path}")

        # 2. 删除文件
        for rel_path in removed:
            processed += 1
            dst = self.old_dir / rel_path

            # 保留文件不删
            if self._match_preserve(rel_path):
                self._progress(processed, total_ops, f"保留: {rel_path}")
                continue

            if dst.exists():
                try:
                    dst.unlink()
                    self._log(f"删除: {rel_path}", "info")
                except IOError as e:
                    self._log(f"删除失败 {rel_path}: {e}", "warning")

            self._progress(processed, total_ops, f"删除: {rel_path}")

        # 3. 清理空目录
        self._clean_empty_dirs()

        # 4. 保存新的基准清单（新整合包的标准状态，用于下次对比判断用户修改）
        new_standard = self.scan_directory(self.new_dir)
        self.save_manifest(new_standard, version_label=backup_name)

        self._progress(total_ops, total_ops, "更新完成!")
        self._log(
            f"更新完成! 新增 {len(added)}，修改 {len(modified)}，删除 {len(removed)}",
            "info"
        )

        return True, f"更新成功！已备份到 {backup_name}"

    def rollback(self, backup_name: str) -> Tuple[bool, str]:
        """
        回退到指定备份
        回退步骤：
        1. 删除本次新增的文件
        2. 从备份恢复被修改的文件（旧版本）
        3. 从备份恢复被删除的文件
        4. 从备份恢复用户修改的配置文件
        :param backup_name: 备份目录名
        :return: (成功与否, 消息)
        """
        backup_path = self.backup_dir / backup_name
        manifest_file = backup_path / "backup_manifest.json"

        if not manifest_file.exists():
            return False, f"找不到备份: {backup_name}"

        try:
            with open(manifest_file, "r", encoding="utf-8") as f:
                manifest = json.load(f)
        except (json.JSONDecodeError, IOError) as e:
            return False, f"读取备份清单失败: {e}"

        self._log(f"开始回退到备份: {backup_name}", "info")

        added_files = manifest.get("added_files", [])
        modified_files = manifest.get("modified_files", [])
        removed_files = manifest.get("removed_files", [])

        # 1. 删除本次新增的文件
        self._log(f"删除新增文件: {len(added_files)} 个", "info")
        for rel_path in added_files:
            dst = self.old_dir / rel_path
            if dst.exists() and dst.is_file():
                try:
                    dst.unlink()
                    self._log(f"删除新增文件: {rel_path}", "info")
                except IOError as e:
                    self._log(f"删除失败 {rel_path}: {e}", "warning")

        # 2. 恢复被修改的文件（从 modified_files 备份）
        modified_backup_dir = backup_path / "modified_files"
        if modified_backup_dir.exists() and modified_files:
            self._log(f"恢复修改文件: {len(modified_files)} 个", "info")
            for rel_path in modified_files:
                src = modified_backup_dir / rel_path
                if not src.exists():
                    self._log(f"备份文件不存在: {rel_path}", "warning")
                    continue
                dst = self.old_dir / rel_path
                try:
                    dst.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(src, dst)
                    self._log(f"恢复修改文件: {rel_path}", "info")
                except IOError as e:
                    self._log(f"恢复失败 {rel_path}: {e}", "warning")

        # 3. 恢复被删除的文件（从 removed_files 备份）
        removed_backup_dir = backup_path / "removed_files"
        if removed_backup_dir.exists() and removed_files:
            self._log(f"恢复删除文件: {len(removed_files)} 个", "info")
            for rel_path in removed_files:
                src = removed_backup_dir / rel_path
                if not src.exists():
                    self._log(f"备份文件不存在: {rel_path}", "warning")
                    continue
                dst = self.old_dir / rel_path
                try:
                    dst.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(src, dst)
                    self._log(f"恢复删除文件: {rel_path}", "info")
                except IOError as e:
                    self._log(f"恢复失败 {rel_path}: {e}", "warning")

        # 4. 恢复用户修改的配置文件（从 user_files 备份）
        user_backup_dir = backup_path / "user_files"
        if user_backup_dir.exists():
            for root, dirs, files in os.walk(user_backup_dir):
                root_path = Path(root)
                rel_root = root_path.relative_to(user_backup_dir)
                for file in files:
                    rel_path = str(rel_root / file).replace("\\", "/")
                    if rel_path.startswith("./"):
                        rel_path = rel_path[2:]
                    src = root_path / file
                    dst = self.old_dir / rel_path
                    try:
                        dst.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copy2(src, dst)
                        self._log(f"恢复用户配置: {rel_path}", "info")
                    except IOError as e:
                        self._log(f"恢复配置失败 {rel_path}: {e}", "warning")

        # 5. 清理空目录
        self._clean_empty_dirs()

        # 6. 更新基准清单
        # 重新扫描当前目录作为基准
        current_files = self.scan_directory(self.old_dir)
        self.save_manifest(current_files, version_label=f"rollback_{backup_name}")

        self._log(f"回退完成: {backup_name}", "info")
        return True, f"已回退到备份 {backup_name}"

    def _clean_empty_dirs(self):
        """清理空目录"""
        for root, dirs, files in os.walk(self.old_dir, topdown=False):
            root_path = Path(root)
            if ".updater" in root_path.parts:
                continue
            if root_path == self.old_dir:
                continue
            try:
                if not any(root_path.iterdir()):
                    root_path.rmdir()
            except OSError:
                pass


def format_size(size_bytes: int) -> str:
    """格式化文件大小"""
    if size_bytes < 1024:
        return f"{size_bytes} B"
    elif size_bytes < 1024 * 1024:
        return f"{size_bytes / 1024:.1f} KB"
    elif size_bytes < 1024 * 1024 * 1024:
        return f"{size_bytes / (1024 * 1024):.1f} MB"
    else:
        return f"{size_bytes / (1024 * 1024 * 1024):.2f} GB"
